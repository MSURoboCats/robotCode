
function [classID, classList] = readCFG()

    classID = [];
    classList = [];
    
    filename = "classes.cfg";

    if ~isfile(fullfile(filename))
        
        disp("No config file found");
        
    else 
        
        fileID = fopen(filename, "r");
        line = fgetl(fileID);
        counter = 1;
        
        while line > -1
            
            line = split(line, " ");
            classID = [classID str2num(line{1})];
            classList = [classList string(line{2})];
            
            line = fgetl(fileID);
            counter = counter + 1;
            
        end        
    end 
    
    classList = classList(1:counter - 1);
    classID = classID(1:counter - 1);
    fclose(fileID);
end

