% convertData converts all video data into image data;
% return values:
% success = 0 if the conversion is unsuccessful
% success = 1 if the conversion is sucessful

function success = convertData()

    % Suppress all warnings, clear console and figures
    clc
    clear
    warning('off','all'); 
    
    %
    % SPECIFY THE FILE TYPE OF THE VIDEO FORMAT HERE
    %
    
    videoFormat = '.avi';
    
    % Read the .cfg file to obtain classIDs and Labels, create vector to store
    % object counts
    %
    % Example:
    % labelCounts(0) == number of times object with ID = 0 appears in data
    %
    [classID, classList, status] = readCFG();
    labelCounts = zeros(1, size(classID, 2));
    
    % Checking status of readCFG. If errors occured during readCFG print
    % the cause of error. Stop the data conversion script if an error
    % occurs
    if (status == 1)
        disp("Problem with config file. 'classes.cfg' does not exist or is" + ...
            " not in the correct directory. Exiting script.");
        success = 0;
        return
    elseif (status == 2)
        disp("Problem with config file. One or more class IDs is either not a number and/or" + ...
            " not an integer. Exiting script.");
        success = 0;
        return
    elseif (status == 4)
        disp("Problem with config file. Config file is empty or formatting" + ...
            " is incorrect. Exiting script.");
        success = 0;
        return
    end
    
    % Define the data directory
    dataStoreDir = "Data";
    if ~exist(fullfile(dataStoreDir), 'dir')
        disp("Data directory either does not exist or this script is in the wrong" + ...
            " directory. Exiting script.");
        success = 0;
        return
    end
    dataStoreInfo = dir(fullfile(dataStoreDir));
    
    % Loop through all files in the data store directory
    for i = 3:size(dataStoreInfo, 1)
        
        % Pull name of video data directory
        dataFolderName = dataStoreInfo(i, 1).name;
        strcmp(dataFolderName, strcat(dataStoreInfo(i-1, 1).name, "_ImageData"));
        
        % Does the current video data folder have a corresponding image data
        % folder?
        % Yes - Don't make a new folder
        % No - Make a new folder to store the frame data
        tempFile = strcat(dataStoreInfo(i-1, 1).name, "_ImageData");
        if (strcmp(dataFolderName, tempFile))
            fprintf("%s already exists.\n", tempFile)
        else
            
            newDataDir = fullfile(dataStoreDir, strcat(dataFolderName, "_ImageData"));
            
            if ~exist(newDataDir, 'dir')
                mkdir(newDataDir);
            end
            
            % Create a list of all videos of format == videoFormat and label files
            videoList = dir(fullfile(dataStoreDir, dataFolderName, strcat('*', videoFormat)));
            labelList = dir(fullfile(dataStoreDir, dataFolderName, '*.mat'));
            
            % Sort the list of labels and videos
            videoList = natsortfiles({videoList.name});
            labelList = natsortfiles({labelList.name});
            
            % Loop through each video in the folder
            for j = 1:size(videoList, 2)
                
                % Extract video information
                vid = VideoReader(fullfile(dataStoreDir, dataFolderName, videoList{1, j}));
                vidName = erase(convertCharsToStrings(vid.Name), videoFormat);
                numFrames = vid.NumFrames;
                vidWidth = vid.Width;
                vidHeight = vid.Height;
                
                if (j > size(labelList, 2))
                    disp("Error: Mismatch between amount of videos and labels." + ...
                        " Check to make sure that all videos have a corresponding label file.")
                    break    
                end
                
                % Extract Label Information
                labels = load(fullfile(dataStoreDir, dataFolderName, labelList{1, j}));
                imageName = convertCharsToStrings(labels.gTruth.LabelDefinitions.Name{1});
                fileNameToStore = fullfile(newDataDir);
                
                % Loop through each frame in the video
                for k = 1:numFrames
                    
                    % If, for some reason, number of frames in the video
                    % exceeds the number of lables in the label file, break
                    if (k > height(labels.gTruth.LabelData))
                      fprintf("Missing labels? Number of frames in %s exceeds the number of labels." + ...
                          " Check video labels in the Video Labeler GUI.\n", vidName);
                      break
                    end
                    
                    % Create new txt file to store frame labels
                    textFilename = fullfile(fileNameToStore, strcat(vidName, "frame", num2str(k), "_", "img.txt"));
                    
                    % Read the current frame of the current video and store
                    % it
                    frame = read(vid, k);
                    imgFilename = fullfile(fileNameToStore, strcat(vidName, "frame", num2str(k), "_", "img.jpg"));
                    imwrite(frame, imgFilename);
                    
                    fileID = fopen(textFilename, "w");
                    
                    % Loop through each object in the frame
                    for numLabels = 1 : size(labels.gTruth.LabelDefinitions, 1)
                        
                        % Extract information about the current label
                        labelNames = labels.gTruth.LabelDefinitions.Name;
                        labelName = labelNames{numLabels};
                        
                        tf = contains(lower(classList), lower(labelName));
                        labelID = classID(tf);
                        %labelName = classList(tf);
                 
                        % Extract the bounding boxes for the current label
                        boundingBoxes = labels.gTruth.LabelData{k, labelName};
                        
                        boundingBoxes = boundingBoxes{1, 1};
                        
                        % Loop through all the bounding boxes for the current
                        % label
                        for z = 1:size(boundingBoxes, 1)
                            
                                currentBoundingBox = boundingBoxes(z, :);
                                
                                % Extract bounding box information and update
                                % the labelCounts vector
                                labelCounts(labelID + 1) = labelCounts(labelID + 1) + 1;
                                xLeftCorner = currentBoundingBox(1);
                                yLeftCorner = currentBoundingBox(2);
                                bBoxWidth = currentBoundingBox(3);
                                bBoxHeight = currentBoundingBox(4);
                                
                                % Calculate the x and y coords of the centriod
                                % of bounding box. Calculate the width and
                                % height of the bounding box, normalized to the
                                % size of the image
                                xCenterRatio = (xLeftCorner + (bBoxWidth/2))/vidWidth;
                                yCenterRatio = (yLeftCorner + (bBoxHeight/2))/vidHeight;
                                bBoxWidthRatio = bBoxWidth/vidWidth;
                                bBoxHeightRatio = bBoxHeight/vidHeight;
                                
                                % Create the string of data and write it to the
                                % data file
                                dataString = strcat(num2str(labelID)," ", num2str(xCenterRatio), " ", ...
                                    num2str(yCenterRatio), " ", num2str(bBoxWidthRatio), " ", ...
                                    num2str(bBoxHeightRatio), "\n");
                                
                                fprintf(fileID, dataString);
                                
                        end
                        
                    end
                    
                    % Close current data file
                    fclose(fileID);
                     
                end  
            end
        end
    end
    
    fprintf("\n\n");
    % Display the frequency of each object type seen in the data set
    for i = 1:size(classList, 2)
        fprintf("%s count is:  %d\n", classList(i),  labelCounts(i))
    end
   
    success = 1;
    
end

